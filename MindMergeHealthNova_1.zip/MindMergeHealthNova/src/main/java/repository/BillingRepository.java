package com.mindmerge.mindmergehealthnova.repository;

import com.mindmerge.mindmergehealthnova.entity.Billing;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BillingRepository extends JpaRepository<Billing, Long> {
}