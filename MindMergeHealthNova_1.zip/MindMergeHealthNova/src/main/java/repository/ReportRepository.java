package com.mindmerge.mindmergehealthnova.repository;

import com.mindmerge.mindmergehealthnova.entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository
        extends JpaRepository<Report, Long> {
}