package com.mindmerge.mindmergehealthnova.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindmerge.mindmergehealthnova.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);
}