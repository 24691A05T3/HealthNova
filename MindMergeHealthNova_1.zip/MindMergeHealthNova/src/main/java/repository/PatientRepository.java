package com.mindmerge.mindmergehealthnova.repository;

import com.mindmerge.mindmergehealthnova.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PatientRepository extends JpaRepository<Patient, Long> {

    List<Patient> findByPatientNameContaining(String patientName);

}