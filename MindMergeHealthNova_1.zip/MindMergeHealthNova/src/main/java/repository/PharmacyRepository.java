package com.mindmerge.mindmergehealthnova.repository;

import com.mindmerge.mindmergehealthnova.entity.Pharmacy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface PharmacyRepository
        extends JpaRepository<Pharmacy, Long> {

    List<Pharmacy> findByExpiryDateBetween(
            LocalDate start,
            LocalDate end
    );
}