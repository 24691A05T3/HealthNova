package com.mindmerge.mindmergehealthnova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MindMergeHealthNovaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MindMergeHealthNovaApplication.class, args);
	}

}
