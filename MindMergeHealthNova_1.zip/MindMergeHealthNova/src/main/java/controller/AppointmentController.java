package com.mindmerge.mindmergehealthnova.controller;

import com.mindmerge.mindmergehealthnova.entity.Appointment;
import com.mindmerge.mindmergehealthnova.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/appointment")
@CrossOrigin("*")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    // Book Appointment
    @PostMapping
    public Appointment bookAppointment(
            @RequestBody Appointment appointment) {

        return appointmentService
                .bookAppointment(
                        appointment);
    }

    // View History
    @GetMapping
    public List<Appointment> getAllAppointments() {

        return appointmentService
                .getAllAppointments();
    }

    // Get Appointment By Id
    @GetMapping("/{id}")
    public Appointment getAppointmentById(
            @PathVariable Long id) {

        return appointmentService
                .getAppointmentById(id);
    }

    // Cancel Appointment
    @PutMapping("/cancel/{id}")
    public String cancelAppointment(
            @PathVariable Long id) {

        return appointmentService
                .cancelAppointment(id);
    }
}