package com.mindmerge.mindmergehealthnova.controller;

import com.mindmerge.mindmergehealthnova.entity.Pharmacy;
import com.mindmerge.mindmergehealthnova.service.PharmacyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pharmacy")
@CrossOrigin(origins = "*")
public class PharmacyController {

    @Autowired
    private PharmacyService pharmacyService;

    @PostMapping
    public Pharmacy addMedicine(@RequestBody Pharmacy pharmacy) {
        return pharmacyService.addMedicine(pharmacy);
    }

    @GetMapping
    public List<Pharmacy> getAllMedicines() {
        return pharmacyService.getAllMedicines();
    }

    @GetMapping("/{id}")
    public Pharmacy getMedicineById(@PathVariable Long id) {
        return pharmacyService.getMedicineById(id);
    }

    @PutMapping("/{id}")
    public Pharmacy updateMedicine(
            @PathVariable Long id,
            @RequestBody Pharmacy pharmacy) {

        return pharmacyService.updateMedicine(id, pharmacy);
    }

    @DeleteMapping("/{id}")
    public String deleteMedicine(@PathVariable Long id) {

        pharmacyService.deleteMedicine(id);

        return "Medicine Deleted Successfully";
    }

    @GetMapping("/expiry")
    public List<Pharmacy> getExpiryMedicines() {
        return pharmacyService.getExpiryMedicines();
    }
}