package com.mindmerge.mindmergehealthnova.controller;

import com.mindmerge.mindmergehealthnova.entity.Billing;
import com.mindmerge.mindmergehealthnova.service.BillingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/billing")
@CrossOrigin(origins = "*")
public class BillingController {

    @Autowired
    private BillingService billingService;

    @PostMapping
    public Billing generateBill(@RequestBody Billing billing) {
        return billingService.generateBill(billing);
    }

    @GetMapping
    public List<Billing> getAllBills() {
        return billingService.getAllBills();
    }

    @GetMapping("/{id}")
    public Billing getBill(@PathVariable Long id) {
        return billingService.getBill(id);
    }

    @DeleteMapping("/{id}")
    public String deleteBill(@PathVariable Long id) {
        billingService.deleteBill(id);
        return "Bill Deleted Successfully";
    }
}