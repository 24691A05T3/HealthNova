package com.mindmerge.mindmergehealthnova.controller;

import com.mindmerge.mindmergehealthnova.entity.Patient;
import com.mindmerge.mindmergehealthnova.service.PatientService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/patients")
@CrossOrigin(origins = "*")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @PostMapping
    public Patient addPatient(
            @RequestBody Patient patient) {

        return patientService.addPatient(patient);
    }

    @GetMapping
    public List<Patient> getAllPatients() {

        return patientService.getAllPatients();
    }

    @GetMapping("/{id}")
    public Patient getPatientById(
            @PathVariable Long id) {

        return patientService.getPatientById(id);
    }

    @PutMapping("/{id}")
    public Patient updatePatient(
            @PathVariable Long id,
            @RequestBody Patient patient) {

        return patientService.updatePatient(id, patient);
    }

    @DeleteMapping("/{id}")
    public String deletePatient(
            @PathVariable Long id) {

        patientService.deletePatient(id);

        return "Patient Deleted Successfully";
    }

    @GetMapping("/search/{name}")
    public List<Patient> searchPatient(
            @PathVariable String name) {

        return patientService.searchPatient(name);
    }
}