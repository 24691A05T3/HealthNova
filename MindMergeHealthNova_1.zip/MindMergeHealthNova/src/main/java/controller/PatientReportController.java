package com.mindmerge.mindmergehealthnova.controller;

import com.mindmerge.mindmergehealthnova.entity.PatientReport;
import com.mindmerge.mindmergehealthnova.repository.PatientReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/reports")
@CrossOrigin(origins = "*")
public class PatientReportController {

    @Autowired
    private PatientReportRepository repository;

    // =========================
    // UPLOAD REPORT
    // =========================
    @PostMapping
    public PatientReport uploadReport(@RequestBody PatientReport report) {

        // auto set upload time
        report.setUploadDate(LocalDateTime.now());

        return repository.save(report);
    }

    // =========================
    // VIEW REPORTS BY PATIENT ID
    // =========================
    @GetMapping("/{patientId}")
    public List<PatientReport> getReportsByPatientId(@PathVariable Long patientId) {
        return repository.findByPatientId(patientId);
    }

    // =========================
    // VIEW ALL REPORTS (OPTIONAL)
    // =========================
    @GetMapping
    public List<PatientReport> getAllReports() {
        return repository.findAll();
    }
}