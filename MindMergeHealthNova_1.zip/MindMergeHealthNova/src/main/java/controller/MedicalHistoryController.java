package com.mindmerge.mindmergehealthnova.controller;

import com.mindmerge.mindmergehealthnova.entity.MedicalHistory;
import com.mindmerge.mindmergehealthnova.repository.MedicalHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/history")
@CrossOrigin(origins = "*")
public class MedicalHistoryController {

    @Autowired
    private MedicalHistoryRepository repository;

    // =========================
    // ADD MEDICAL HISTORY
    // =========================
    @PostMapping
    public MedicalHistory addHistory(@RequestBody MedicalHistory history) {
        return repository.save(history);
    }

    // =========================
    // VIEW HISTORY BY PATIENT ID
    // =========================
    @GetMapping("/{patientId}")
    public List<MedicalHistory> getByPatientId(@PathVariable Long patientId) {
        return repository.findByPatientId(patientId);
    }

    // =========================
    // VIEW ALL HISTORY (OPTIONAL)
    // =========================
    @GetMapping
    public List<MedicalHistory> getAllHistory() {
        return repository.findAll();
    }
}