package com.mindmerge.mindmergehealthnova.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.mindmerge.mindmergehealthnova.dto.LoginDTO;
import com.mindmerge.mindmergehealthnova.dto.RegisterDTO;
import com.mindmerge.mindmergehealthnova.dto.AuthResponse;
import com.mindmerge.mindmergehealthnova.entity.User;
import com.mindmerge.mindmergehealthnova.repository.UserRepository;
import com.mindmerge.mindmergehealthnova.util.JwtUtil;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    // ✅ REGISTER
    public String register(RegisterDTO dto) {

        Optional<User> existingUser = userRepository.findByEmail(dto.getEmail());

        if (existingUser.isPresent()) {
            return "Email already exists";
        }

        User user = new User();
        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setRole( dto.getRole().toUpperCase());

        userRepository.save(user);

        return "Registration Successful";
    }

    // ✅ LOGIN (FIXED - returns JWT + role)
    public AuthResponse login(LoginDTO dto) {

        Optional<User> userOptional = userRepository.findByEmail(dto.getEmail());

        if (userOptional.isEmpty()) {
            throw new RuntimeException("Invalid Email");
        }

        User user = userOptional.get();
        System.out.print("Role:"+user.getRole());


        boolean passwordMatch =
                passwordEncoder.matches(dto.getPassword(), user.getPassword());

        if (!passwordMatch) {
            throw new RuntimeException("Invalid Password");
        }

        String token = JwtUtil.generateToken(user.getEmail(), user.getRole());

        return new AuthResponse(token, user.getRole(), user.getEmail());
    }
}