package com.mindmerge.mindmergehealthnova.service;

import com.mindmerge.mindmergehealthnova.entity.Appointment;
import com.mindmerge.mindmergehealthnova.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    // Book Appointment
    public Appointment bookAppointment(
            Appointment appointment) {

        appointment.setStatus("BOOKED");

        return appointmentRepository.save(
                appointment);
    }

    // View Appointment History
    public List<Appointment> getAllAppointments() {

        return appointmentRepository.findAll();
    }

    // Get Appointment By Id
    public Appointment getAppointmentById(Long id) {

        return appointmentRepository
                .findById(id)
                .orElse(null);
    }

    // Cancel Appointment
    public String cancelAppointment(Long id) {

        Appointment appointment =
                appointmentRepository
                        .findById(id)
                        .orElse(null);

        if (appointment != null) {

            appointment.setStatus("CANCELLED");

            appointmentRepository.save(
                    appointment);

            return "Appointment Cancelled";
        }

        return "Appointment Not Found";
    }
}