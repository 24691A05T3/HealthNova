package com.mindmerge.mindmergehealthnova.service;

import com.mindmerge.mindmergehealthnova.entity.Report;
import com.mindmerge.mindmergehealthnova.repository.ReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReportService {

    @Autowired
    private ReportRepository reportRepository;

    public Report generateReport(Report report) {

        report.setGeneratedDate(LocalDateTime.now());

        return reportRepository.save(report);
    }

    public List<Report> getAllReports() {
        return reportRepository.findAll();
    }

    public Report getReport(Long id) {

        return reportRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Report Not Found"));
    }

    public void deleteReport(Long id) {
        reportRepository.deleteById(id);
    }
}