package com.mindmerge.mindmergehealthnova.service;

import com.mindmerge.mindmergehealthnova.entity.Patient;
import com.mindmerge.mindmergehealthnova.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    public Patient addPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatientById(Long id) {
        return patientRepository.findById(id).orElse(null);
    }

    public Patient updatePatient(Long id, Patient patient) {

        Patient existing = patientRepository.findById(id).orElse(null);

        if(existing != null) {

            existing.setPatientName(patient.getPatientName());
            existing.setAge(patient.getAge());
            existing.setGender(patient.getGender());
            existing.setPhone(patient.getPhone());
            existing.setAddress(patient.getAddress());
            existing.setDisease(patient.getDisease());

            return patientRepository.save(existing);
        }

        return null;
    }

    public void deletePatient(Long id) {
        patientRepository.deleteById(id);
    }

    public List<Patient> searchPatient(String name) {
        return patientRepository.findByPatientNameContaining(name);
    }
}