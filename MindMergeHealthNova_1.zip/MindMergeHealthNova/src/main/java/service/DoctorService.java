package com.mindmerge.mindmergehealthnova.service;

import com.mindmerge.mindmergehealthnova.entity.Doctor;
import com.mindmerge.mindmergehealthnova.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    // Add Doctor
    public Doctor addDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    // View All Doctors
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    // View Doctor By ID
    public Doctor getDoctorById(Long id) {

        Optional<Doctor> doctor =
                doctorRepository.findById(id);

        return doctor.orElse(null);
    }

    // Update Doctor
    public Doctor updateDoctor(Long id,
                               Doctor doctorDetails) {

        Optional<Doctor> optionalDoctor =
                doctorRepository.findById(id);

        if (optionalDoctor.isPresent()) {

            Doctor doctor = optionalDoctor.get();

            doctor.setName(
                    doctorDetails.getName());

            doctor.setDepartment(
                    doctorDetails.getDepartment());

            doctor.setSpecialization(
                    doctorDetails.getSpecialization());

            doctor.setAvailability(
                    doctorDetails.getAvailability());

            doctor.setSchedule(
                    doctorDetails.getSchedule());

            return doctorRepository.save(doctor);
        }

        return null;
    }

    // Delete Doctor
    public String deleteDoctor(Long id) {

        if (doctorRepository.existsById(id)) {

            doctorRepository.deleteById(id);

            return "Doctor Deleted Successfully";
        }

        return "Doctor Not Found";
    }

    // Search Doctor By Name
    public List<Doctor> searchDoctor(String name) {

        return doctorRepository
                .findByNameContainingIgnoreCase(name);
    }
}