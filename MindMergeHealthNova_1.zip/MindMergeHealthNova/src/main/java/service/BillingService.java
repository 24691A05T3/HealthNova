package com.mindmerge.mindmergehealthnova.service;

import com.mindmerge.mindmergehealthnova.entity.Billing;
import com.mindmerge.mindmergehealthnova.repository.BillingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BillingService {

    @Autowired
    private BillingRepository billingRepository;

    public Billing generateBill(Billing billing) {

        double subtotal =
                billing.getConsultationFee()
                        + billing.getMedicineFee()
                        + billing.getLabFee();

        double gst = subtotal * 0.18;

        billing.setGst(gst);
        billing.setTotalAmount(subtotal + gst);

        return billingRepository.save(billing);
    }

    public List<Billing> getAllBills() {
        return billingRepository.findAll();
    }

    public Billing getBill(Long id) {
        return billingRepository.findById(id).orElse(null);
    }

    public void deleteBill(Long id) {
        billingRepository.deleteById(id);
    }
}