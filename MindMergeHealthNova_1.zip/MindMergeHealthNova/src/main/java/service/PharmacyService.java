package com.mindmerge.mindmergehealthnova.service;

import com.mindmerge.mindmergehealthnova.entity.Pharmacy;
import com.mindmerge.mindmergehealthnova.repository.PharmacyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PharmacyService {

    @Autowired
    private PharmacyRepository pharmacyRepository;

    public Pharmacy addMedicine(Pharmacy pharmacy) {

        pharmacy.setTotalPrice(
                pharmacy.getQuantity() * pharmacy.getUnitPrice()
        );

        return pharmacyRepository.save(pharmacy);
    }

    public List<Pharmacy> getAllMedicines() {
        return pharmacyRepository.findAll();
    }

    public Pharmacy getMedicineById(Long id) {

        return pharmacyRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Medicine Not Found"));
    }

    public Pharmacy updateMedicine(Long id, Pharmacy pharmacy) {

        Pharmacy existing = getMedicineById(id);

        existing.setMedicineName(pharmacy.getMedicineName());
        existing.setQuantity(pharmacy.getQuantity());
        existing.setUnitPrice(pharmacy.getUnitPrice());
        existing.setExpiryDate(pharmacy.getExpiryDate());

        existing.setTotalPrice(
                pharmacy.getQuantity() * pharmacy.getUnitPrice()
        );

        return pharmacyRepository.save(existing);
    }

    public void deleteMedicine(Long id) {
        pharmacyRepository.deleteById(id);
    }

    public List<Pharmacy> getExpiryMedicines() {

        LocalDate today = LocalDate.now();
        LocalDate next30Days = today.plusDays(30);

        return pharmacyRepository
                .findByExpiryDateBetween(today, next30Days);
    }
}